export default {
  Jake: [
    {
      id: "2",
      content:
        "Sucking at something is the first step towards being sorta good at something.",
      author: {
        id: "1",
        name: "Jake",
        url: "http://adventuretime.wikia.com/wiki/Jake",
        avatarUrl: "jakeImg",
        colors: {
          soft: "#FFFAE6",
          hard: "#FFC400"
        }
      }
    },
    {
      id: "3",
      content: "You got to focus on what's real, man",
      author: {
        id: "1",
        name: "Jake",
        url: "http://adventuretime.wikia.com/wiki/Jake",
        avatarUrl: "jakeImg",
        colors: {
          soft: "#FFFAE6",
          hard: "#FFC400"
        }
      }
    }
  ],
  BMO: [
    {
      id: "1",
      content: "Sometimes life is scary and dark",
      author: {
        id: "2",
        name: "BMO",
        url: "http://adventuretime.wikia.com/wiki/BMO",
        avatarUrl: "bmoImg",
        colors: {
          soft: "#E3FCEF",
          hard: "#57D9A3"
        }
      }
    }
  ],
  Finn: [
    {
      id: "4",
      content: "Is that where creativity comes from? From sad biz?",
      author: {
        id: "3",
        name: "Finn",
        url: "http://adventuretime.wikia.com/wiki/Finn",
        avatarUrl: "finnImg",
        colors: {
          soft: "#DEEBFF",
          hard: "#2684FF"
        }
      }
    },
    {
      id: "5",
      content: "Homies help homies. Always",
      author: {
        id: "3",
        name: "Finn",
        url: "http://adventuretime.wikia.com/wiki/Finn",
        avatarUrl: "finnImg",
        colors: {
          soft: "#DEEBFF",
          hard: "#2684FF"
        }
      }
    },
    {
      id: "8",
      content: "People make mistakes. It’s a part of growing up",
      author: {
        id: "3",
        name: "Finn",
        url: "http://adventuretime.wikia.com/wiki/Finn",
        avatarUrl: "finnImg",
        colors: {
          soft: "#DEEBFF",
          hard: "#2684FF"
        }
      }
    },
    {
      id: "9",
      content:
        "Don't you always call sweatpants 'give up on life pants,' Jake?",
      author: {
        id: "3",
        name: "Finn",
        url: "http://adventuretime.wikia.com/wiki/Finn",
        avatarUrl: "finnImg",
        colors: {
          soft: "#DEEBFF",
          hard: "#2684FF"
        }
      }
    }
  ],
  "Princess bubblegum": [
    {
      id: "6",
      content: "Responsibility demands sacrifice",
      author: {
        id: "4",
        name: "Princess bubblegum",
        url: "http://adventuretime.wikia.com/wiki/Princess_Bubblegum",
        avatarUrl: "princessImg",
        colors: {
          soft: "#EAE6FF",
          hard: "#8777D9"
        }
      }
    },
    {
      id: "7",
      content:
        "That's it! The answer was so simple, I was too smart to see it!",
      author: {
        id: "4",
        name: "Princess bubblegum",
        url: "http://adventuretime.wikia.com/wiki/Princess_Bubblegum",
        avatarUrl: "princessImg",
        colors: {
          soft: "#EAE6FF",
          hard: "#8777D9"
        }
      }
    },
    {
      id: "10",
      content: "I should not have drunk that much tea!",
      author: {
        id: "4",
        name: "Princess bubblegum",
        url: "http://adventuretime.wikia.com/wiki/Princess_Bubblegum",
        avatarUrl: "princessImg",
        colors: {
          soft: "#EAE6FF",
          hard: "#8777D9"
        }
      }
    },
    {
      id: "11",
      content: "Please! I need the real you!",
      author: {
        id: "4",
        name: "Princess bubblegum",
        url: "http://adventuretime.wikia.com/wiki/Princess_Bubblegum",
        avatarUrl: "princessImg",
        colors: {
          soft: "#EAE6FF",
          hard: "#8777D9"
        }
      }
    }
  ],
  Prin: [
    {
      id: "12",
      content: "Haven't slept for a solid 83 hours, but, yeah, I'm good.",
      author: {
        id: "5",
        name: "Prin",
        url: "http://adventuretime.wikia.com/wiki/Princess_Bubblegum",
        avatarUrl: "princessImg",
        colors: {
          soft: "#EAE6FF",
          hard: "#8777D9"
        }
      }
    },
    {
      id: "13",
      content: "Haven't slept for a solid 83 hours, but, yeah, I'm good.",
      author: {
        id: "5",
        name: "Prin",
        url: "http://adventuretime.wikia.com/wiki/Princess_Bubblegum",
        avatarUrl: "princessImg",
        colors: {
          soft: "#EAE6FF",
          hard: "#8777D9"
        }
      }
    },
    {
      id: "14",
      content: "Haven't slept for a solid 83 hours, but, yeah, I'm good.",
      author: {
        id: "5",
        name: "Prin",
        url: "http://adventuretime.wikia.com/wiki/Princess_Bubblegum",
        avatarUrl: "princessImg",
        colors: {
          soft: "#EAE6FF",
          hard: "#8777D9"
        }
      }
    }
  ],
  Ted: []
};
