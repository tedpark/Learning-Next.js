module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = require('../../../ssr-module-cache.js');
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 5);
/******/ })
/************************************************************************/
/******/ ({

/***/ "./JsonData.js":
/*!*********************!*\
  !*** ./JsonData.js ***!
  \*********************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ({
  Jake: [{
    id: "2",
    content: "Sucking at something is the first step towards being sorta good at something.",
    author: {
      id: "1",
      name: "Jake",
      url: "http://adventuretime.wikia.com/wiki/Jake",
      avatarUrl: "jakeImg",
      colors: {
        soft: "#FFFAE6",
        hard: "#FFC400"
      }
    }
  }, {
    id: "3",
    content: "You got to focus on what's real, man",
    author: {
      id: "1",
      name: "Jake",
      url: "http://adventuretime.wikia.com/wiki/Jake",
      avatarUrl: "jakeImg",
      colors: {
        soft: "#FFFAE6",
        hard: "#FFC400"
      }
    }
  }],
  BMO: [{
    id: "1",
    content: "Sometimes life is scary and dark",
    author: {
      id: "2",
      name: "BMO",
      url: "http://adventuretime.wikia.com/wiki/BMO",
      avatarUrl: "bmoImg",
      colors: {
        soft: "#E3FCEF",
        hard: "#57D9A3"
      }
    }
  }],
  Finn: [{
    id: "4",
    content: "Is that where creativity comes from? From sad biz?",
    author: {
      id: "3",
      name: "Finn",
      url: "http://adventuretime.wikia.com/wiki/Finn",
      avatarUrl: "finnImg",
      colors: {
        soft: "#DEEBFF",
        hard: "#2684FF"
      }
    }
  }, {
    id: "5",
    content: "Homies help homies. Always",
    author: {
      id: "3",
      name: "Finn",
      url: "http://adventuretime.wikia.com/wiki/Finn",
      avatarUrl: "finnImg",
      colors: {
        soft: "#DEEBFF",
        hard: "#2684FF"
      }
    }
  }, {
    id: "8",
    content: "People make mistakes. It’s a part of growing up",
    author: {
      id: "3",
      name: "Finn",
      url: "http://adventuretime.wikia.com/wiki/Finn",
      avatarUrl: "finnImg",
      colors: {
        soft: "#DEEBFF",
        hard: "#2684FF"
      }
    }
  }, {
    id: "9",
    content: "Don't you always call sweatpants 'give up on life pants,' Jake?",
    author: {
      id: "3",
      name: "Finn",
      url: "http://adventuretime.wikia.com/wiki/Finn",
      avatarUrl: "finnImg",
      colors: {
        soft: "#DEEBFF",
        hard: "#2684FF"
      }
    }
  }],
  "Princess bubblegum": [{
    id: "6",
    content: "Responsibility demands sacrifice",
    author: {
      id: "4",
      name: "Princess bubblegum",
      url: "http://adventuretime.wikia.com/wiki/Princess_Bubblegum",
      avatarUrl: "princessImg",
      colors: {
        soft: "#EAE6FF",
        hard: "#8777D9"
      }
    }
  }, {
    id: "7",
    content: "That's it! The answer was so simple, I was too smart to see it!",
    author: {
      id: "4",
      name: "Princess bubblegum",
      url: "http://adventuretime.wikia.com/wiki/Princess_Bubblegum",
      avatarUrl: "princessImg",
      colors: {
        soft: "#EAE6FF",
        hard: "#8777D9"
      }
    }
  }, {
    id: "10",
    content: "I should not have drunk that much tea!",
    author: {
      id: "4",
      name: "Princess bubblegum",
      url: "http://adventuretime.wikia.com/wiki/Princess_Bubblegum",
      avatarUrl: "princessImg",
      colors: {
        soft: "#EAE6FF",
        hard: "#8777D9"
      }
    }
  }, {
    id: "11",
    content: "Please! I need the real you!",
    author: {
      id: "4",
      name: "Princess bubblegum",
      url: "http://adventuretime.wikia.com/wiki/Princess_Bubblegum",
      avatarUrl: "princessImg",
      colors: {
        soft: "#EAE6FF",
        hard: "#8777D9"
      }
    }
  }],
  Prin: [{
    id: "12",
    content: "Haven't slept for a solid 83 hours, but, yeah, I'm good.",
    author: {
      id: "5",
      name: "Prin",
      url: "http://adventuretime.wikia.com/wiki/Princess_Bubblegum",
      avatarUrl: "princessImg",
      colors: {
        soft: "#EAE6FF",
        hard: "#8777D9"
      }
    }
  }, {
    id: "13",
    content: "Haven't slept for a solid 83 hours, but, yeah, I'm good.",
    author: {
      id: "5",
      name: "Prin",
      url: "http://adventuretime.wikia.com/wiki/Princess_Bubblegum",
      avatarUrl: "princessImg",
      colors: {
        soft: "#EAE6FF",
        hard: "#8777D9"
      }
    }
  }, {
    id: "14",
    content: "Haven't slept for a solid 83 hours, but, yeah, I'm good.",
    author: {
      id: "5",
      name: "Prin",
      url: "http://adventuretime.wikia.com/wiki/Princess_Bubblegum",
      avatarUrl: "princessImg",
      colors: {
        soft: "#EAE6FF",
        hard: "#8777D9"
      }
    }
  }],
  Ted: []
});

/***/ }),

/***/ "./assets/bmo.png":
/*!************************!*\
  !*** ./assets/bmo.png ***!
  \************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/_next/static/bmo.png";

/***/ }),

/***/ "./assets/finn.png":
/*!*************************!*\
  !*** ./assets/finn.png ***!
  \*************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/_next/static/finn.png";

/***/ }),

/***/ "./assets/jake.png":
/*!*************************!*\
  !*** ./assets/jake.png ***!
  \*************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/_next/static/jake.png";

/***/ }),

/***/ "./assets/princess.png":
/*!*****************************!*\
  !*** ./assets/princess.png ***!
  \*****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/_next/static/princess.png";

/***/ }),

/***/ "./constants.js":
/*!**********************!*\
  !*** ./constants.js ***!
  \**********************/
/*! exports provided: grid, borderRadius */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "grid", function() { return grid; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "borderRadius", function() { return borderRadius; });
const grid = 8;
const borderRadius = 2;

/***/ }),

/***/ "./containers/Kanban/board/board.js":
/*!******************************************!*\
  !*** ./containers/Kanban/board/board.js ***!
  \******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return Board; });
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/extends */ "./node_modules/@babel/runtime-corejs2/helpers/esm/extends.js");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_objectSpread__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/objectSpread */ "./node_modules/@babel/runtime-corejs2/helpers/esm/objectSpread.js");
/* harmony import */ var _babel_runtime_corejs2_core_js_object_keys__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @babel/runtime-corejs2/core-js/object/keys */ "./node_modules/@babel/runtime-corejs2/core-js/object/keys.js");
/* harmony import */ var _babel_runtime_corejs2_core_js_object_keys__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_corejs2_core_js_object_keys__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/defineProperty */ "./node_modules/@babel/runtime-corejs2/helpers/esm/defineProperty.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @emotion/styled */ "@emotion/styled");
/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_emotion_styled__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _emotion_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @emotion/core */ "@emotion/core");
/* harmony import */ var _emotion_core__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_emotion_core__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _atlaskit_theme__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @atlaskit/theme */ "@atlaskit/theme");
/* harmony import */ var _atlaskit_theme__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_atlaskit_theme__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _column__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./column */ "./containers/Kanban/board/column.js");
/* harmony import */ var _reorder__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../reorder */ "./containers/Kanban/reorder.js");
/* harmony import */ var react_beautiful_dnd__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! react-beautiful-dnd */ "react-beautiful-dnd");
/* harmony import */ var react_beautiful_dnd__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react_beautiful_dnd__WEBPACK_IMPORTED_MODULE_10__);




var _jsxFileName = "/Users/ted/bitlocal/Learning-Next.js/3. Introduce My Todo Manager/MyTodoManager/containers/Kanban/board/board.js";



 // import type {
//   DropResult,
//   DraggableLocation,
//   DroppableProvided,
// } from '../../../src';
// import type { QuoteMap, Quote } from '../types';




const ParentContainer = _emotion_styled__WEBPACK_IMPORTED_MODULE_5___default.a.div`
  height: ${({
  height
}) => height};
  overflow-x: hidden;
  overflow-y: auto;
`;
const Container = _emotion_styled__WEBPACK_IMPORTED_MODULE_5___default.a.div`
  background-color: ${_atlaskit_theme__WEBPACK_IMPORTED_MODULE_7__["colors"].B100};
  min-height: 100vh;
  /* like display:flex but will allow bleeding over the window width */
  min-width: 100vw;
  display: inline-flex;
`;
class Board extends react__WEBPACK_IMPORTED_MODULE_4__["Component"] {
  constructor(...args) {
    super(...args);

    Object(_babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_3__["default"])(this, "state", {
      columns: this.props.initial,
      ordered: _babel_runtime_corejs2_core_js_object_keys__WEBPACK_IMPORTED_MODULE_2___default()(this.props.initial)
    });

    Object(_babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_3__["default"])(this, "boardRef", void 0);

    Object(_babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_3__["default"])(this, "onDragEnd", result => {
      if (result.combine) {
        if (result.type === "COLUMN") {
          const shallow = [...this.state.ordered];
          shallow.splice(result.source.index, 1);
          this.setState({
            ordered: shallow
          });
          return;
        }

        const column = this.state.columns[result.source.droppableId];
        const withQuoteRemoved = [...column];
        withQuoteRemoved.splice(result.source.index, 1);

        const columns = Object(_babel_runtime_corejs2_helpers_esm_objectSpread__WEBPACK_IMPORTED_MODULE_1__["default"])({}, this.state.columns, {
          [result.source.droppableId]: withQuoteRemoved
        });

        this.setState({
          columns
        });
        return;
      } // dropped nowhere


      if (!result.destination) {
        return;
      }

      const source = result.source;
      const destination = result.destination; // did not move anywhere - can bail early

      if (source.droppableId === destination.droppableId && source.index === destination.index) {
        return;
      } // reordering column


      if (result.type === "COLUMN") {
        const ordered = Object(_reorder__WEBPACK_IMPORTED_MODULE_9__["default"])(this.state.ordered, source.index, destination.index);
        this.setState({
          ordered
        });
        return;
      }

      const data = Object(_reorder__WEBPACK_IMPORTED_MODULE_9__["reorderQuoteMap"])({
        quoteMap: this.state.columns,
        source,
        destination
      });
      this.setState({
        columns: data.quoteMap
      });
    });
  }

  render() {
    Object(react_beautiful_dnd__WEBPACK_IMPORTED_MODULE_10__["resetServerContext"])();
    const columns = this.state.columns;
    const ordered = this.state.ordered;
    const {
      containerHeight
    } = this.props;
    const board = react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(react_beautiful_dnd__WEBPACK_IMPORTED_MODULE_10__["Droppable"], {
      droppableId: "board",
      type: "COLUMN",
      direction: "horizontal",
      ignoreContainerClipping: Boolean(containerHeight),
      isCombineEnabled: this.props.isCombineEnabled,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 116
      },
      __self: this
    }, provided => react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(Container, Object(_babel_runtime_corejs2_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__["default"])({
      ref: provided.innerRef
    }, provided.droppableProps, {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 124
      },
      __self: this
    }), ordered.map((key, index) => react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(_column__WEBPACK_IMPORTED_MODULE_8__["default"], {
      key: key,
      index: index,
      title: key,
      quotes: columns[key],
      isScrollable: this.props.withScrollableColumns,
      isCombineEnabled: this.props.isCombineEnabled,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 126
      },
      __self: this
    })), provided.placeholder));
    return react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_4___default.a.Fragment, {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 142
      },
      __self: this
    }, react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(react_beautiful_dnd__WEBPACK_IMPORTED_MODULE_10__["DragDropContext"], {
      onDragEnd: this.onDragEnd,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 143
      },
      __self: this
    }, containerHeight ? react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(ParentContainer, {
      height: containerHeight,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 145
      },
      __self: this
    }, board) : board), react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(_emotion_core__WEBPACK_IMPORTED_MODULE_6__["Global"], {
      styles: _emotion_core__WEBPACK_IMPORTED_MODULE_6__["css"]`
            body {
              background: ${_atlaskit_theme__WEBPACK_IMPORTED_MODULE_7__["colors"].B200};
            }
          `,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 150
      },
      __self: this
    }));
  }

}

Object(_babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_3__["default"])(Board, "defaultProps", {
  isCombineEnabled: false
});

/***/ }),

/***/ "./containers/Kanban/board/column.js":
/*!*******************************************!*\
  !*** ./containers/Kanban/board/column.js ***!
  \*******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return Column; });
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/extends */ "./node_modules/@babel/runtime-corejs2/helpers/esm/extends.js");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/defineProperty */ "./node_modules/@babel/runtime-corejs2/helpers/esm/defineProperty.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @emotion/styled */ "@emotion/styled");
/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_emotion_styled__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _atlaskit_theme__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @atlaskit/theme */ "@atlaskit/theme");
/* harmony import */ var _atlaskit_theme__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_atlaskit_theme__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../constants */ "./constants.js");
/* harmony import */ var react_beautiful_dnd__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react-beautiful-dnd */ "react-beautiful-dnd");
/* harmony import */ var react_beautiful_dnd__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_beautiful_dnd__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_modal__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! react-modal */ "react-modal");
/* harmony import */ var react_modal__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_modal__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _primatives_quote_list__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../primatives/quote-list */ "./containers/Kanban/primatives/quote-list.js");
/* harmony import */ var _primatives_title__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../primatives/title */ "./containers/Kanban/primatives/title.js");
/* harmony import */ var rbx__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! rbx */ "rbx");
/* harmony import */ var rbx__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(rbx__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var rbx_index_css__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! rbx/index.css */ "./node_modules/rbx/index.css");
/* harmony import */ var rbx_index_css__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(rbx_index_css__WEBPACK_IMPORTED_MODULE_11__);


var _jsxFileName = "/Users/ted/bitlocal/Learning-Next.js/3. Introduce My Todo Manager/MyTodoManager/containers/Kanban/board/column.js";





 // import type { DraggableProvided, DraggableStateSnapshot } from '../../../src';


 // import type { Quote } from '../types';



const Container = _emotion_styled__WEBPACK_IMPORTED_MODULE_3___default.a.div`
  margin: ${_constants__WEBPACK_IMPORTED_MODULE_5__["grid"]}px;
  display: flex;
  flex-direction: column;
`;
const Header = _emotion_styled__WEBPACK_IMPORTED_MODULE_3___default.a.div`
  display: flex;
  align-items: center;
  justify-content: center;
  border-top-left-radius: ${_constants__WEBPACK_IMPORTED_MODULE_5__["borderRadius"]}px;
  border-top-right-radius: ${_constants__WEBPACK_IMPORTED_MODULE_5__["borderRadius"]}px;
  background-color: ${({
  isDragging
}) => isDragging ? _atlaskit_theme__WEBPACK_IMPORTED_MODULE_4__["colors"].G50 : _atlaskit_theme__WEBPACK_IMPORTED_MODULE_4__["colors"].N30};
  transition: background-color 0.2s ease;

  &:hover {
    background-color: ${_atlaskit_theme__WEBPACK_IMPORTED_MODULE_4__["colors"].G50};
  }
`;
react_modal__WEBPACK_IMPORTED_MODULE_7___default.a.setAppElement("#__next");
const customStyles = {
  overlay: {
    backgroundColor: "rgba(52, 52, 52, 0.8)"
  },
  // modal: {
  //   top: "50%",
  //   left: "50%",
  //   right: "auto",
  //   bottom: "auto",
  //   marginRight: "-50%",
  //   transform: "translate(-50%, -50%)"
  // },
  content: {
    top: "50%",
    height: "200px",
    left: "50%",
    border: "0px",
    color: "white",
    backgroundColor: "#155B9C",
    right: "auto",
    bottom: "auto",
    marginRight: "-50%",
    transform: "translate(-50%, -50%)"
  }
};
class Column extends react__WEBPACK_IMPORTED_MODULE_2__["Component"] {
  constructor() {
    super();

    Object(_babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "handleOpenModal", () => {
      this.setState({
        showModal: true
      });
    });

    Object(_babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "handleCloseModal", () => {
      this.setState({
        showModal: false
      });
    });

    this.state = {
      showModal: false
    };
  }

  render() {
    const title = this.props.title;
    const quotes = this.props.quotes;
    const index = this.props.index;
    return react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("div", {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 85
      },
      __self: this
    }, react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(react_beautiful_dnd__WEBPACK_IMPORTED_MODULE_6__["Draggable"], {
      draggableId: title,
      index: index,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 86
      },
      __self: this
    }, (provided, snapshot) => react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(Container, Object(_babel_runtime_corejs2_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__["default"])({
      ref: provided.innerRef
    }, provided.draggableProps, {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 88
      },
      __self: this
    }), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(Header, {
      isDragging: snapshot.isDragging,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 89
      },
      __self: this
    }, react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_primatives_title__WEBPACK_IMPORTED_MODULE_9__["default"], Object(_babel_runtime_corejs2_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__["default"])({
      isDragging: snapshot.isDragging
    }, provided.dragHandleProps, {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 90
      },
      __self: this
    }), title), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(rbx__WEBPACK_IMPORTED_MODULE_10__["Button"], {
      style: {
        margin: 10
      },
      color: "info" // onClick={() => console.log(title)}
      ,
      onClick: () => this.handleOpenModal(),
      __source: {
        fileName: _jsxFileName,
        lineNumber: 96
      },
      __self: this
    }, react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("strong", {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 102
      },
      __self: this
    }, "Add"))), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_primatives_quote_list__WEBPACK_IMPORTED_MODULE_8__["default"], {
      listId: title,
      listType: "QUOTE",
      style: {
        backgroundColor: snapshot.isDragging ? _atlaskit_theme__WEBPACK_IMPORTED_MODULE_4__["colors"].G50 : null
      },
      quotes: quotes,
      internalScroll: this.props.isScrollable,
      isCombineEnabled: Boolean(this.props.isCombineEnabled),
      __source: {
        fileName: _jsxFileName,
        lineNumber: 105
      },
      __self: this
    }))), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(react_modal__WEBPACK_IMPORTED_MODULE_7___default.a // style={{ width: 20 }}
    , {
      style: customStyles,
      isOpen: this.state.showModal,
      contentLabel: "onRequestClose Example",
      onRequestClose: () => this.handleCloseModal(),
      __source: {
        fileName: _jsxFileName,
        lineNumber: 118
      },
      __self: this
    }, react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(rbx__WEBPACK_IMPORTED_MODULE_10__["Control"], {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 126
      },
      __self: this
    }, react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("div", {
      style: {
        flex: 1,
        flexDirection: "row",
        justifyContent: "flex-end"
      },
      __source: {
        fileName: _jsxFileName,
        lineNumber: 127
      },
      __self: this
    }, react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(rbx__WEBPACK_IMPORTED_MODULE_10__["Textarea"], {
      style: {
        width: 340
      },
      placeholder: "Todo...",
      fixedSize: true,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 134
      },
      __self: this
    }), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(rbx__WEBPACK_IMPORTED_MODULE_10__["Button"], {
      style: {
        marginTop: 10,
        position: "absolute",
        right: 0
      },
      color: "info",
      onClick: () => this.handleCloseModal(),
      __source: {
        fileName: _jsxFileName,
        lineNumber: 139
      },
      __self: this
    }, react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("strong", {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 144
      },
      __self: this
    }, "Save"))))));
  }

}

/***/ }),

/***/ "./containers/Kanban/primatives/quote-item.js":
/*!****************************************************!*\
  !*** ./containers/Kanban/primatives/quote-item.js ***!
  \****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/extends */ "./node_modules/@babel/runtime-corejs2/helpers/esm/extends.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @emotion/styled */ "@emotion/styled");
/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_emotion_styled__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _atlaskit_theme__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @atlaskit/theme */ "@atlaskit/theme");
/* harmony import */ var _atlaskit_theme__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_atlaskit_theme__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../constants */ "./constants.js");
/* harmony import */ var _assets_jake_png__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../assets/jake.png */ "./assets/jake.png");
/* harmony import */ var _assets_jake_png__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_assets_jake_png__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _assets_finn_png__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../assets/finn.png */ "./assets/finn.png");
/* harmony import */ var _assets_finn_png__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_assets_finn_png__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _assets_bmo_png__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../assets/bmo.png */ "./assets/bmo.png");
/* harmony import */ var _assets_bmo_png__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_assets_bmo_png__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _assets_princess_png__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../assets/princess.png */ "./assets/princess.png");
/* harmony import */ var _assets_princess_png__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_assets_princess_png__WEBPACK_IMPORTED_MODULE_8__);

var _jsxFileName = "/Users/ted/bitlocal/Learning-Next.js/3. Introduce My Todo Manager/MyTodoManager/containers/Kanban/primatives/quote-item.js";
// @flow







 // import type { Quote, AuthorColors } from '../types';
// import type { DraggableProvided } from '../../../src';
// Props = {
//   quote: Quote,
//   isDragging: boolean,
//   provided: DraggableProvided,
//   isGroupedOver?: boolean
// };

const getBackgroundColor = (isDragging, isGroupedOver, authorColors) => {
  if (isDragging) {
    return authorColors.soft;
  }

  if (isGroupedOver) {
    return _atlaskit_theme__WEBPACK_IMPORTED_MODULE_3__["colors"].N30;
  }

  return _atlaskit_theme__WEBPACK_IMPORTED_MODULE_3__["colors"].N0;
};

const getBorderColor = (isDragging, authorColors) => isDragging ? authorColors.hard : "transparent";

const Container = _emotion_styled__WEBPACK_IMPORTED_MODULE_2___default.a.a`
  border-radius: ${_constants__WEBPACK_IMPORTED_MODULE_4__["borderRadius"]}px;
  border: 2px solid transparent;
  border-color: ${props => getBorderColor(props.isDragging, props.colors)};
  background-color: ${props => getBackgroundColor(props.isDragging, props.isGroupedOver, props.colors)};
  box-shadow: ${({
  isDragging
}) => isDragging ? `2px 2px 1px ${_atlaskit_theme__WEBPACK_IMPORTED_MODULE_3__["colors"].N70}` : "none"};
  padding: ${_constants__WEBPACK_IMPORTED_MODULE_4__["grid"]}px;
  min-height: 40px;
  margin-bottom: ${_constants__WEBPACK_IMPORTED_MODULE_4__["grid"]}px;
  user-select: none;

  /* anchor overrides */
  color: ${_atlaskit_theme__WEBPACK_IMPORTED_MODULE_3__["colors"].N900};

  &:hover,
  &:active {
    color: ${_atlaskit_theme__WEBPACK_IMPORTED_MODULE_3__["colors"].N900};
    text-decoration: none;
  }

  &:focus {
    outline: none;
    border-color: ${props => props.colors.hard};
    box-shadow: none;
  }

  /* flexbox */
  display: flex;
`;
const Avatar = _emotion_styled__WEBPACK_IMPORTED_MODULE_2___default.a.img`
  width: 40px;
  height: 40px;
  border-radius: 50%;
  margin-right: ${_constants__WEBPACK_IMPORTED_MODULE_4__["grid"]}px;
  flex-shrink: 0;
  flex-grow: 0;
`;
const Content = _emotion_styled__WEBPACK_IMPORTED_MODULE_2___default.a.div`
  /* flex child */
  flex-grow: 1;

  /*
    Needed to wrap text in ie11
    https://stackoverflow.com/questions/35111090/why-ie11-doesnt-wrap-the-text-in-flexbox
  */
  flex-basis: 100%;

  /* flex parent */
  display: flex;
  flex-direction: column;
`;
const BlockQuote = _emotion_styled__WEBPACK_IMPORTED_MODULE_2___default.a.div`
  &::before {
    content: open-quote;
  }

  &::after {
    content: close-quote;
  }
`;
const Footer = _emotion_styled__WEBPACK_IMPORTED_MODULE_2___default.a.div`
  display: flex;
  margin-top: ${_constants__WEBPACK_IMPORTED_MODULE_4__["grid"]}px;
  align-items: center;
`;
const Author = _emotion_styled__WEBPACK_IMPORTED_MODULE_2___default.a.small`
  flex-grow: 0;
  margin: 0;
  background-color: ${props => props.colors.soft};
  border-radius: ${_constants__WEBPACK_IMPORTED_MODULE_4__["borderRadius"]}px;
  font-weight: normal;
  padding: ${_constants__WEBPACK_IMPORTED_MODULE_4__["grid"] / 2}px;
`;
const QuoteId = _emotion_styled__WEBPACK_IMPORTED_MODULE_2___default.a.small`
  flex-grow: 1;
  flex-shrink: 1;
  margin: 0;
  font-weight: normal;
  text-overflow: ellipsis;
  text-align: right;
`;

function getImage(params) {
  switch (params) {
    case "jakeImg":
      return _assets_jake_png__WEBPACK_IMPORTED_MODULE_5___default.a;
      break;

    case "finnImg":
      return _assets_finn_png__WEBPACK_IMPORTED_MODULE_6___default.a;
      break;

    case "bmoImg":
      return _assets_bmo_png__WEBPACK_IMPORTED_MODULE_7___default.a;
      break;

    case "princessImg":
      return _assets_princess_png__WEBPACK_IMPORTED_MODULE_8___default.a;
      break;

    default: // code block

  }
} // Previously this extended React.Component
// That was a good thing, because using React.PureComponent can hide
// issues with the selectors. However, moving it over does can considerable
// performance improvements when reordering big lists (400ms => 200ms)
// Need to be super sure we are not relying on PureComponent here for
// things we should be doing in the selector as we do not know if consumers
// will be using PureComponent


function QuoteItem(props) {
  const {
    quote,
    isDragging,
    isGroupedOver,
    provided
  } = props;
  return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Container, Object(_babel_runtime_corejs2_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__["default"])({
    href: quote.author.url,
    isDragging: isDragging,
    isGroupedOver: isGroupedOver,
    colors: quote.author.colors,
    ref: provided.innerRef
  }, provided.draggableProps, provided.dragHandleProps, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 155
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Avatar, {
    src: getImage(quote.author.avatarUrl),
    alt: quote.author.name,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 164
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Content, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 165
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(BlockQuote, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 166
    },
    __self: this
  }, quote.content), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Footer, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 167
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Author, {
    colors: quote.author.colors,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 168
    },
    __self: this
  }, quote.author.name), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(QuoteId, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 169
    },
    __self: this
  }, "id:", quote.id))));
}

/* harmony default export */ __webpack_exports__["default"] = (react__WEBPACK_IMPORTED_MODULE_1___default.a.memo(QuoteItem)); // import jakeImg from "../../assets/jake.png";
// import finnImg from "../../assets/finn.png";
// import bmoImg from "../../assets/bmo.png";
// import princessImg from "../../assets/princess.png";

/***/ }),

/***/ "./containers/Kanban/primatives/quote-list.js":
/*!****************************************************!*\
  !*** ./containers/Kanban/primatives/quote-list.js ***!
  \****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return QuoteList; });
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/extends */ "./node_modules/@babel/runtime-corejs2/helpers/esm/extends.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @emotion/styled */ "@emotion/styled");
/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_emotion_styled__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _atlaskit_theme__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @atlaskit/theme */ "@atlaskit/theme");
/* harmony import */ var _atlaskit_theme__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_atlaskit_theme__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_beautiful_dnd__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react-beautiful-dnd */ "react-beautiful-dnd");
/* harmony import */ var react_beautiful_dnd__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_beautiful_dnd__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _quote_item__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./quote-item */ "./containers/Kanban/primatives/quote-item.js");
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../constants */ "./constants.js");
/* harmony import */ var _title__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./title */ "./containers/Kanban/primatives/title.js");

var _jsxFileName = "/Users/ted/bitlocal/Learning-Next.js/3. Introduce My Todo Manager/MyTodoManager/containers/Kanban/primatives/quote-list.js";






 // import type { Quote } from '../types';
// import type {
//   DroppableProvided,
//   DroppableStateSnapshot,
//   DraggableProvided,
//   DraggableStateSnapshot,
// } from '../../../src';

const getBackgroundColor = (isDraggingOver, isDraggingFrom) => {
  if (isDraggingOver) {
    return _atlaskit_theme__WEBPACK_IMPORTED_MODULE_3__["colors"].R50;
  }

  if (isDraggingFrom) {
    return _atlaskit_theme__WEBPACK_IMPORTED_MODULE_3__["colors"].T50;
  }

  return _atlaskit_theme__WEBPACK_IMPORTED_MODULE_3__["colors"].N30;
};

const Wrapper = _emotion_styled__WEBPACK_IMPORTED_MODULE_2___default.a.div`
  background-color: ${props => getBackgroundColor(props.isDraggingOver, props.isDraggingFrom)};
  display: flex;
  flex-direction: column;
  opacity: ${({
  isDropDisabled
}) => isDropDisabled ? 0.5 : "inherit"};
  padding: ${_constants__WEBPACK_IMPORTED_MODULE_6__["grid"]}px;
  border: ${_constants__WEBPACK_IMPORTED_MODULE_6__["grid"]}px;
  padding-bottom: 0;
  transition: background-color 0.2s ease, opacity 0.1s ease;
  user-select: none;
  width: 250px;
`;
const scrollContainerHeight = 250;
const DropZone = _emotion_styled__WEBPACK_IMPORTED_MODULE_2___default.a.div`
  /* stop the list collapsing when empty */
  min-height: ${scrollContainerHeight}px;

  /*
    not relying on the items for a margin-bottom
    as it will collapse when the list is empty
  */
  padding-bottom: ${_constants__WEBPACK_IMPORTED_MODULE_6__["grid"]}px;
`;
const ScrollContainer = _emotion_styled__WEBPACK_IMPORTED_MODULE_2___default.a.div`
  overflow-x: hidden;
  overflow-y: auto;
  max-height: ${scrollContainerHeight}px;
`;
/* stylelint-disable block-no-empty */

const Container = _emotion_styled__WEBPACK_IMPORTED_MODULE_2___default.a.div``;
/* stylelint-enable */
// type Props = {|
//   listId?: string,
//   listType?: string,
//   quotes: Quote[],
//   title?: string,
//   internalScroll?: boolean,
//   scrollContainerStyle?: Object,
//   isDropDisabled?: boolean,
//   isCombineEnabled?: boolean,
//   style?: Object,
//   // may not be provided - and might be null
//   ignoreContainerClipping?: boolean
// |};
// type QuoteListProps = {|
//   quotes: Quote[]
// |};

const InnerQuoteList = react__WEBPACK_IMPORTED_MODULE_1___default.a.memo(function InnerQuoteList(props) {
  return props.quotes.map((quote, index) => react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(react_beautiful_dnd__WEBPACK_IMPORTED_MODULE_4__["Draggable"], {
    key: quote.id,
    draggableId: quote.id,
    index: index,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 83
    },
    __self: this
  }, (dragProvided, dragSnapshot) => react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_quote_item__WEBPACK_IMPORTED_MODULE_5__["default"], {
    key: quote.id,
    quote: quote,
    isDragging: dragSnapshot.isDragging,
    isGroupedOver: Boolean(dragSnapshot.combineTargetFor),
    provided: dragProvided,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 85
    },
    __self: this
  })));
}); // type InnerListProps = {|
//   dropProvided: DroppableProvided,
//   quotes: Quote[],
//   title: ?string
// |};

function InnerList(props) {
  const {
    quotes,
    dropProvided
  } = props;
  const title = props.title ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_title__WEBPACK_IMPORTED_MODULE_7__["default"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 105
    },
    __self: this
  }, props.title) : null;
  return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Container, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 108
    },
    __self: this
  }, title, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(DropZone, {
    ref: dropProvided.innerRef,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 110
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(InnerQuoteList, {
    quotes: quotes,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 111
    },
    __self: this
  }), dropProvided.placeholder));
}

function QuoteList(props) {
  const {
    ignoreContainerClipping,
    internalScroll,
    scrollContainerStyle,
    isDropDisabled,
    isCombineEnabled,
    listId = "LIST",
    listType,
    style,
    quotes,
    title
  } = props;
  return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(react_beautiful_dnd__WEBPACK_IMPORTED_MODULE_4__["Droppable"], {
    droppableId: listId,
    type: listType,
    ignoreContainerClipping: ignoreContainerClipping,
    isDropDisabled: isDropDisabled,
    isCombineEnabled: isCombineEnabled,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 133
    },
    __self: this
  }, (dropProvided, dropSnapshot) => react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Wrapper, Object(_babel_runtime_corejs2_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__["default"])({
    style: style,
    isDraggingOver: dropSnapshot.isDraggingOver,
    isDropDisabled: isDropDisabled,
    isDraggingFrom: Boolean(dropSnapshot.draggingFromThisWith)
  }, dropProvided.droppableProps, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 141
    },
    __self: this
  }), internalScroll ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(ScrollContainer, {
    style: scrollContainerStyle,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 149
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(InnerList, {
    quotes: quotes,
    title: title,
    dropProvided: dropProvided,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 150
    },
    __self: this
  })) : react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(InnerList, {
    quotes: quotes,
    title: title,
    dropProvided: dropProvided,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 157
    },
    __self: this
  })));
}

/***/ }),

/***/ "./containers/Kanban/primatives/title.js":
/*!***********************************************!*\
  !*** ./containers/Kanban/primatives/title.js ***!
  \***********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @emotion/styled */ "@emotion/styled");
/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_emotion_styled__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _atlaskit_theme__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @atlaskit/theme */ "@atlaskit/theme");
/* harmony import */ var _atlaskit_theme__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_atlaskit_theme__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../constants */ "./constants.js");



/* harmony default export */ __webpack_exports__["default"] = (_emotion_styled__WEBPACK_IMPORTED_MODULE_0___default.a.h4`
  padding: ${_constants__WEBPACK_IMPORTED_MODULE_2__["grid"]}px;
  transition: background-color ease 0.2s;
  flex-grow: 1;
  user-select: none;
  position: relative;

  &:focus {
    outline: 2px solid ${_atlaskit_theme__WEBPACK_IMPORTED_MODULE_1__["colors"].P100};
    outline-offset: 2px;
  }
`);

/***/ }),

/***/ "./containers/Kanban/reorder.js":
/*!**************************************!*\
  !*** ./containers/Kanban/reorder.js ***!
  \**************************************/
/*! exports provided: default, reorderQuoteMap */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "reorderQuoteMap", function() { return reorderQuoteMap; });
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_objectSpread__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/objectSpread */ "./node_modules/@babel/runtime-corejs2/helpers/esm/objectSpread.js");
/* harmony import */ var _babel_runtime_corejs2_core_js_array_from__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime-corejs2/core-js/array/from */ "./node_modules/@babel/runtime-corejs2/core-js/array/from.js");
/* harmony import */ var _babel_runtime_corejs2_core_js_array_from__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_corejs2_core_js_array_from__WEBPACK_IMPORTED_MODULE_1__);



// import type { Quote, QuoteMap } from './types';
// import type { DraggableLocation } from '../../src/types';
// a little function to help us with reordering the result
const reorder = (list, startIndex, endIndex) => {
  const result = _babel_runtime_corejs2_core_js_array_from__WEBPACK_IMPORTED_MODULE_1___default()(list);

  const [removed] = result.splice(startIndex, 1);
  result.splice(endIndex, 0, removed);
  return result;
};

/* harmony default export */ __webpack_exports__["default"] = (reorder); // ReorderQuoteMapArgs = {
//   quoteMap,
//   source,
//   destination
// };
// ReorderQuoteMapResult = {
//   quoteMap
// };

const reorderQuoteMap = ({
  quoteMap,
  source,
  destination
}) => {
  const current = [...quoteMap[source.droppableId]];
  const next = [...quoteMap[destination.droppableId]];
  const target = current[source.index]; // moving to same list

  if (source.droppableId === destination.droppableId) {
    const reordered = reorder(current, source.index, destination.index);

    const result = Object(_babel_runtime_corejs2_helpers_esm_objectSpread__WEBPACK_IMPORTED_MODULE_0__["default"])({}, quoteMap, {
      [source.droppableId]: reordered
    });

    return {
      quoteMap: result
    };
  } // moving to different list
  // remove from original


  current.splice(source.index, 1); // insert into next

  next.splice(destination.index, 0, target);

  const result = Object(_babel_runtime_corejs2_helpers_esm_objectSpread__WEBPACK_IMPORTED_MODULE_0__["default"])({}, quoteMap, {
    [source.droppableId]: current,
    [destination.droppableId]: next
  });

  return {
    quoteMap: result
  };
};

/***/ }),

/***/ "./data.js":
/*!*****************!*\
  !*** ./data.js ***!
  \*****************/
/*! exports provided: authors, quotes, getQuotes, getAuthors, authorQuoteMap, generateQuoteMap */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "authors", function() { return authors; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "quotes", function() { return quotes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getQuotes", function() { return getQuotes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getAuthors", function() { return getAuthors; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "authorQuoteMap", function() { return authorQuoteMap; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "generateQuoteMap", function() { return generateQuoteMap; });
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_objectSpread__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/objectSpread */ "./node_modules/@babel/runtime-corejs2/helpers/esm/objectSpread.js");
/* harmony import */ var _babel_runtime_corejs2_core_js_array_from__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime-corejs2/core-js/array/from */ "./node_modules/@babel/runtime-corejs2/core-js/array/from.js");
/* harmony import */ var _babel_runtime_corejs2_core_js_array_from__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_corejs2_core_js_array_from__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _atlaskit_theme__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @atlaskit/theme */ "@atlaskit/theme");
/* harmony import */ var _atlaskit_theme__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_atlaskit_theme__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _assets_jake_png__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./assets/jake.png */ "./assets/jake.png");
/* harmony import */ var _assets_jake_png__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_assets_jake_png__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _assets_finn_png__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./assets/finn.png */ "./assets/finn.png");
/* harmony import */ var _assets_finn_png__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_assets_finn_png__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _assets_bmo_png__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./assets/bmo.png */ "./assets/bmo.png");
/* harmony import */ var _assets_bmo_png__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_assets_bmo_png__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _assets_princess_png__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./assets/princess.png */ "./assets/princess.png");
/* harmony import */ var _assets_princess_png__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_assets_princess_png__WEBPACK_IMPORTED_MODULE_6__);


// @flow




 // let jakeImg = "jakeImg";
// let finnImg = "finnImg";
// let bmoImg = "bmoImg";
// let princessImg = "princessImg";

const jake = {
  id: "1",
  name: "Jake",
  url: "http://adventuretime.wikia.com/wiki/Jake",
  avatarUrl: _assets_jake_png__WEBPACK_IMPORTED_MODULE_3___default.a,
  colors: {
    soft: _atlaskit_theme__WEBPACK_IMPORTED_MODULE_2__["colors"].Y50,
    hard: _atlaskit_theme__WEBPACK_IMPORTED_MODULE_2__["colors"].Y200
  }
};
const BMO = {
  id: "2",
  name: "BMO",
  url: "http://adventuretime.wikia.com/wiki/BMO",
  avatarUrl: _assets_bmo_png__WEBPACK_IMPORTED_MODULE_5___default.a,
  colors: {
    soft: _atlaskit_theme__WEBPACK_IMPORTED_MODULE_2__["colors"].G50,
    hard: _atlaskit_theme__WEBPACK_IMPORTED_MODULE_2__["colors"].G200
  }
};
const finn = {
  id: "3",
  name: "Finn",
  url: "http://adventuretime.wikia.com/wiki/Finn",
  avatarUrl: _assets_finn_png__WEBPACK_IMPORTED_MODULE_4___default.a,
  colors: {
    soft: _atlaskit_theme__WEBPACK_IMPORTED_MODULE_2__["colors"].B50,
    hard: _atlaskit_theme__WEBPACK_IMPORTED_MODULE_2__["colors"].B200
  }
};
const princess = {
  id: "4",
  name: "Princess bubblegum",
  url: "http://adventuretime.wikia.com/wiki/Princess_Bubblegum",
  avatarUrl: _assets_princess_png__WEBPACK_IMPORTED_MODULE_6___default.a,
  colors: {
    soft: _atlaskit_theme__WEBPACK_IMPORTED_MODULE_2__["colors"].P50,
    hard: _atlaskit_theme__WEBPACK_IMPORTED_MODULE_2__["colors"].P200
  }
};
const prin = {
  id: "5",
  name: "Prin",
  url: "http://adventuretime.wikia.com/wiki/Princess_Bubblegum",
  avatarUrl: _assets_princess_png__WEBPACK_IMPORTED_MODULE_6___default.a,
  colors: {
    soft: _atlaskit_theme__WEBPACK_IMPORTED_MODULE_2__["colors"].P50,
    hard: _atlaskit_theme__WEBPACK_IMPORTED_MODULE_2__["colors"].P200
  }
};
const ted = {
  id: "6",
  name: "Ted",
  url: "http://adventuretime.wikia.com/wiki/Princess_Bubblegum",
  avatarUrl: _assets_princess_png__WEBPACK_IMPORTED_MODULE_6___default.a,
  colors: {
    soft: _atlaskit_theme__WEBPACK_IMPORTED_MODULE_2__["colors"].P50,
    hard: _atlaskit_theme__WEBPACK_IMPORTED_MODULE_2__["colors"].P200
  }
};
const authors = [jake, BMO, finn, princess, prin, ted];
const quotes = [{
  id: "1",
  content: "Sometimes life is scary and dark",
  author: BMO
}, {
  id: "2",
  content: "Sucking at something is the first step towards being sorta good at something.",
  author: jake
}, {
  id: "3",
  content: "You got to focus on what's real, man",
  author: jake
}, {
  id: "4",
  content: "Is that where creativity comes from? From sad biz?",
  author: finn
}, {
  id: "5",
  content: "Homies help homies. Always",
  author: finn
}, {
  id: "6",
  content: "Responsibility demands sacrifice",
  author: princess
}, {
  id: "7",
  content: "That's it! The answer was so simple, I was too smart to see it!",
  author: princess
}, {
  id: "8",
  content: "People make mistakes. It’s a part of growing up",
  author: finn
}, {
  id: "9",
  content: "Don't you always call sweatpants 'give up on life pants,' Jake?",
  author: finn
}, {
  id: "10",
  content: "I should not have drunk that much tea!",
  author: princess
}, {
  id: "11",
  content: "Please! I need the real you!",
  author: princess
}, {
  id: "12",
  content: "Haven't slept for a solid 83 hours, but, yeah, I'm good.",
  author: prin
}, {
  id: "13",
  content: "Haven't slept for a solid 83 hours, but, yeah, I'm good.",
  author: prin
}, {
  id: "14",
  content: "Haven't slept for a solid 83 hours, but, yeah, I'm good.",
  author: prin
}]; // So we do not have any clashes with our hardcoded ones

let idCount = quotes.length + 2;
const getQuotes = count => _babel_runtime_corejs2_core_js_array_from__WEBPACK_IMPORTED_MODULE_1___default()({
  length: count
}, (v, k) => k).map(() => {
  const random = quotes[Math.floor(Math.random() * quotes.length)];

  const custom = Object(_babel_runtime_corejs2_helpers_esm_objectSpread__WEBPACK_IMPORTED_MODULE_0__["default"])({}, random, {
    id: `G${idCount++}`
  });

  return custom;
});
const getAuthors = count => _babel_runtime_corejs2_core_js_array_from__WEBPACK_IMPORTED_MODULE_1___default()({
  length: count
}, (v, k) => k).map(() => {
  const random = authors[Math.floor(Math.random() * authors.length)];

  const custom = Object(_babel_runtime_corejs2_helpers_esm_objectSpread__WEBPACK_IMPORTED_MODULE_0__["default"])({}, random, {
    id: `author-${idCount++}`
  });

  return custom;
});

const getByAuthor = (author, items) => items.filter(quote => quote.author === author);

const authorQuoteMap = authors.reduce((previous, author) => Object(_babel_runtime_corejs2_helpers_esm_objectSpread__WEBPACK_IMPORTED_MODULE_0__["default"])({}, previous, {
  [author.name]: getByAuthor(author, quotes)
}), {});
const generateQuoteMap = quoteCount => authors.reduce((previous, author) => Object(_babel_runtime_corejs2_helpers_esm_objectSpread__WEBPACK_IMPORTED_MODULE_0__["default"])({}, previous, {
  [author.name]: getQuotes(quoteCount / authors.length)
}), {});

/***/ }),

/***/ "./node_modules/@babel/runtime-corejs2/core-js/array/from.js":
/*!*******************************************************************!*\
  !*** ./node_modules/@babel/runtime-corejs2/core-js/array/from.js ***!
  \*******************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! core-js/library/fn/array/from */ "core-js/library/fn/array/from");

/***/ }),

/***/ "./node_modules/@babel/runtime-corejs2/core-js/object/assign.js":
/*!**********************************************************************!*\
  !*** ./node_modules/@babel/runtime-corejs2/core-js/object/assign.js ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! core-js/library/fn/object/assign */ "core-js/library/fn/object/assign");

/***/ }),

/***/ "./node_modules/@babel/runtime-corejs2/core-js/object/define-property.js":
/*!*******************************************************************************!*\
  !*** ./node_modules/@babel/runtime-corejs2/core-js/object/define-property.js ***!
  \*******************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! core-js/library/fn/object/define-property */ "core-js/library/fn/object/define-property");

/***/ }),

/***/ "./node_modules/@babel/runtime-corejs2/core-js/object/get-own-property-descriptor.js":
/*!*******************************************************************************************!*\
  !*** ./node_modules/@babel/runtime-corejs2/core-js/object/get-own-property-descriptor.js ***!
  \*******************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! core-js/library/fn/object/get-own-property-descriptor */ "core-js/library/fn/object/get-own-property-descriptor");

/***/ }),

/***/ "./node_modules/@babel/runtime-corejs2/core-js/object/get-own-property-symbols.js":
/*!****************************************************************************************!*\
  !*** ./node_modules/@babel/runtime-corejs2/core-js/object/get-own-property-symbols.js ***!
  \****************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! core-js/library/fn/object/get-own-property-symbols */ "core-js/library/fn/object/get-own-property-symbols");

/***/ }),

/***/ "./node_modules/@babel/runtime-corejs2/core-js/object/keys.js":
/*!********************************************************************!*\
  !*** ./node_modules/@babel/runtime-corejs2/core-js/object/keys.js ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! core-js/library/fn/object/keys */ "core-js/library/fn/object/keys");

/***/ }),

/***/ "./node_modules/@babel/runtime-corejs2/helpers/esm/defineProperty.js":
/*!***************************************************************************!*\
  !*** ./node_modules/@babel/runtime-corejs2/helpers/esm/defineProperty.js ***!
  \***************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return _defineProperty; });
/* harmony import */ var _core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../core-js/object/define-property */ "./node_modules/@babel/runtime-corejs2/core-js/object/define-property.js");
/* harmony import */ var _core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0__);

function _defineProperty(obj, key, value) {
  if (key in obj) {
    _core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0___default()(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }

  return obj;
}

/***/ }),

/***/ "./node_modules/@babel/runtime-corejs2/helpers/esm/extends.js":
/*!********************************************************************!*\
  !*** ./node_modules/@babel/runtime-corejs2/helpers/esm/extends.js ***!
  \********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return _extends; });
/* harmony import */ var _core_js_object_assign__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../core-js/object/assign */ "./node_modules/@babel/runtime-corejs2/core-js/object/assign.js");
/* harmony import */ var _core_js_object_assign__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_assign__WEBPACK_IMPORTED_MODULE_0__);

function _extends() {
  _extends = _core_js_object_assign__WEBPACK_IMPORTED_MODULE_0___default.a || function (target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];

      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }

    return target;
  };

  return _extends.apply(this, arguments);
}

/***/ }),

/***/ "./node_modules/@babel/runtime-corejs2/helpers/esm/objectSpread.js":
/*!*************************************************************************!*\
  !*** ./node_modules/@babel/runtime-corejs2/helpers/esm/objectSpread.js ***!
  \*************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return _objectSpread; });
/* harmony import */ var _core_js_object_get_own_property_descriptor__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../core-js/object/get-own-property-descriptor */ "./node_modules/@babel/runtime-corejs2/core-js/object/get-own-property-descriptor.js");
/* harmony import */ var _core_js_object_get_own_property_descriptor__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_get_own_property_descriptor__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _core_js_object_get_own_property_symbols__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../core-js/object/get-own-property-symbols */ "./node_modules/@babel/runtime-corejs2/core-js/object/get-own-property-symbols.js");
/* harmony import */ var _core_js_object_get_own_property_symbols__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_get_own_property_symbols__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _core_js_object_keys__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../core-js/object/keys */ "./node_modules/@babel/runtime-corejs2/core-js/object/keys.js");
/* harmony import */ var _core_js_object_keys__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_keys__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _defineProperty__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./defineProperty */ "./node_modules/@babel/runtime-corejs2/helpers/esm/defineProperty.js");




function _objectSpread(target) {
  for (var i = 1; i < arguments.length; i++) {
    var source = arguments[i] != null ? arguments[i] : {};

    var ownKeys = _core_js_object_keys__WEBPACK_IMPORTED_MODULE_2___default()(source);

    if (typeof _core_js_object_get_own_property_symbols__WEBPACK_IMPORTED_MODULE_1___default.a === 'function') {
      ownKeys = ownKeys.concat(_core_js_object_get_own_property_symbols__WEBPACK_IMPORTED_MODULE_1___default()(source).filter(function (sym) {
        return _core_js_object_get_own_property_descriptor__WEBPACK_IMPORTED_MODULE_0___default()(source, sym).enumerable;
      }));
    }

    ownKeys.forEach(function (key) {
      Object(_defineProperty__WEBPACK_IMPORTED_MODULE_3__["default"])(target, key, source[key]);
    });
  }

  return target;
}

/***/ }),

/***/ "./node_modules/rbx/index.css":
/*!************************************!*\
  !*** ./node_modules/rbx/index.css ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {



/***/ }),

/***/ "./pages/main.js":
/*!***********************!*\
  !*** ./pages/main.js ***!
  \***********************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return Main; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var rbx__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rbx */ "rbx");
/* harmony import */ var rbx__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(rbx__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var rbx_index_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rbx/index.css */ "./node_modules/rbx/index.css");
/* harmony import */ var rbx_index_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(rbx_index_css__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _JsonData__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../JsonData */ "./JsonData.js");
/* harmony import */ var _containers_Kanban_board_board__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../containers/Kanban/board/board */ "./containers/Kanban/board/board.js");
/* harmony import */ var _data__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../data */ "./data.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! axios */ "axios");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_6__);
var _jsxFileName = "/Users/ted/bitlocal/Learning-Next.js/3. Introduce My Todo Manager/MyTodoManager/pages/main.js";








async function getKanbanData() {
  try {
    const response = await axios__WEBPACK_IMPORTED_MODULE_6___default.a.get("http://localhost:3000" + "/todos");
    console.log(response); // this.setState({
    //   view: <MainLayoutView />
    // });
    //TODO if login Success go MainLayoutView
  } catch (error) {
    console.error(error);
  }
}

const data = {
  medium: Object(_data__WEBPACK_IMPORTED_MODULE_5__["generateQuoteMap"])(100),
  large: Object(_data__WEBPACK_IMPORTED_MODULE_5__["generateQuoteMap"])(500)
};
function Main() {
  Object(react__WEBPACK_IMPORTED_MODULE_0__["useEffect"])(() => {
    getKanbanData();
  });
  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_containers_Kanban_board_board__WEBPACK_IMPORTED_MODULE_4__["default"], {
    initial: _JsonData__WEBPACK_IMPORTED_MODULE_3__["default"],
    __source: {
      fileName: _jsxFileName,
      lineNumber: 40
    },
    __self: this
  });
}

/***/ }),

/***/ 5:
/*!*****************************!*\
  !*** multi ./pages/main.js ***!
  \*****************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! /Users/ted/bitlocal/Learning-Next.js/3. Introduce My Todo Manager/MyTodoManager/pages/main.js */"./pages/main.js");


/***/ }),

/***/ "@atlaskit/theme":
/*!**********************************!*\
  !*** external "@atlaskit/theme" ***!
  \**********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@atlaskit/theme");

/***/ }),

/***/ "@emotion/core":
/*!********************************!*\
  !*** external "@emotion/core" ***!
  \********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@emotion/core");

/***/ }),

/***/ "@emotion/styled":
/*!**********************************!*\
  !*** external "@emotion/styled" ***!
  \**********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@emotion/styled");

/***/ }),

/***/ "axios":
/*!************************!*\
  !*** external "axios" ***!
  \************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("axios");

/***/ }),

/***/ "core-js/library/fn/array/from":
/*!************************************************!*\
  !*** external "core-js/library/fn/array/from" ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/array/from");

/***/ }),

/***/ "core-js/library/fn/object/assign":
/*!***************************************************!*\
  !*** external "core-js/library/fn/object/assign" ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/assign");

/***/ }),

/***/ "core-js/library/fn/object/define-property":
/*!************************************************************!*\
  !*** external "core-js/library/fn/object/define-property" ***!
  \************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/define-property");

/***/ }),

/***/ "core-js/library/fn/object/get-own-property-descriptor":
/*!************************************************************************!*\
  !*** external "core-js/library/fn/object/get-own-property-descriptor" ***!
  \************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/get-own-property-descriptor");

/***/ }),

/***/ "core-js/library/fn/object/get-own-property-symbols":
/*!*********************************************************************!*\
  !*** external "core-js/library/fn/object/get-own-property-symbols" ***!
  \*********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/get-own-property-symbols");

/***/ }),

/***/ "core-js/library/fn/object/keys":
/*!*************************************************!*\
  !*** external "core-js/library/fn/object/keys" ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/keys");

/***/ }),

/***/ "rbx":
/*!**********************!*\
  !*** external "rbx" ***!
  \**********************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("rbx");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react");

/***/ }),

/***/ "react-beautiful-dnd":
/*!**************************************!*\
  !*** external "react-beautiful-dnd" ***!
  \**************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react-beautiful-dnd");

/***/ }),

/***/ "react-modal":
/*!******************************!*\
  !*** external "react-modal" ***!
  \******************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react-modal");

/***/ })

/******/ });
//# sourceMappingURL=main.js.map